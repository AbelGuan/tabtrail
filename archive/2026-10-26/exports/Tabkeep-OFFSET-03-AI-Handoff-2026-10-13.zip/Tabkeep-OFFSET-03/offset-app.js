
const glyphs={arrow:'M5 19 19 5 M5 5h14v14',right:'M4 12h16 m-6-6 6 6-6 6',grid:'M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z',list:'M8 5h13 M8 12h13 M8 19h13 M3 5h1 M3 12h1 M3 19h1',tabs:'M3 8h18v13H3z M7 8V3h14v5',bookmark:'M6 3h12v18l-6-4-6 4z',clock:'M12 6v6l4 3 M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',history:'M3 9a9 9 0 1 1 0 6 M3 3v6h6 M12 7v5l-4 2',folder:'M3 5h7l2 3h9v12H3z',spark:'m12 2 3 7 7 3-7 3-3 7-3-7-7-3 7-3z',all:'M4 4h16v16H4z M4 9h16 M9 9v11',search:'m16 16 5 5 M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0',eye:'M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7 M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0',more:'M5 11v2 M12 11v2 M19 11v2',sun:'M12 1v3 M12 20v3 M1 12h3 M20 12h3 M4 4l2 2 M18 18l2 2 M20 4l-2 2 M4 20l2-2 M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0',moon:'M20 15A9 9 0 0 1 9 3a9 9 0 1 0 11 12',settings:'M3 7h18 M3 17h18 M8 3v8 M16 13v8',info:'M12 10v7 M12 6v1 M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',close:'M5 5l14 14 M19 5 5 19',menu:'M3 6h18 M3 12h18 M3 18h18',check:'m4 12 5 5L20 5',lock:'M6 10h12v11H6z M8 10V6a4 4 0 0 1 8 0v4',refresh:'M20 8a9 9 0 1 0 1 7 M20 3v6h-6'};
const I=n=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${glyphs[n]||glyphs.folder}"/></svg>`;
const E=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const groups=['设计与造物','代码与逻辑','阅读与远方','日常与生活','待整理'];
const folders=['书签栏 / 设计档案','书签栏 / 开发文档','其他书签 / 慢慢读','其他书签 / 生活切片'];
const seed=[
 ['Form follows curiosity','form.example','设计与造物','不是每个想法都需要答案。有些只需要被好好留下。','F','poster','#84734d'],
 ['Figma · 拾页的下一个形状','figma.com','设计与造物','从界面草图到可使用的组件，一份仍在生长的设计稿。','F','design','#7f6890'],
 ['Objects of everyday life','objects.example','设计与造物','平凡物件里的材料、结构，以及经得起时间的细节。','O','objects','#a46c47'],
 ['Type foundry · 字体观察','type.example','设计与造物','字里行间，藏着一整个世界的性格。','Aa','type','#556b5d'],
 ['GitHub · Tabkeep workspace','github.com','代码与逻辑','一个关于信息归位的实验。组件、逻辑与本地优先。','G','code','#54695a'],
 ['MDN · The shape of CSS Grid','developer.mozilla.org','代码与逻辑','用网格组织空间，给内容留出呼吸的余地。','M','grid','#58717a'],
 ['Local-first, human-first','local.example','代码与逻辑','让数据留在身边，让工具保持安静。','L','code','#7b8061'],
 ['A slower kind of internet','slow.example','阅读与远方','少一点刷新，多一点真正值得回来的地方。','s','article','#97735b'],
 ['Field notes · 山野之间','field.example','阅读与远方','风经过森林。我们经过一段不需要赶路的时间。','f','landscape','#6f805d'],
 ['The quiet practice of noticing','noticing.example','阅读与远方','一些没有目的的观察，一本永远写不完的笔记。','N','article','#786f5f'],
 ['京都 · 留一天给小路','kyoto.example','日常与生活','离开主街，去寻找雨后的庭院和一间小咖啡馆。','旅','landscape','#8c7658'],
 ['Sunday table · 不赶时间的午餐','sunday.example','日常与生活','陶器、时令蔬菜，以及愿意坐下来的人。','S','objects','#a77252'],
 ['一个尚未命名的灵感','new.example','待整理','先留下，再想想它属于哪里。','n',null,'#7b816c'],
 ['关于未来工作方式的片段','future.example','待整理','等待下一次整理的页面。','↗',null,'#7b816c']
];
const make=(s,i,p)=>({id:p+i,title:s[0],domain:s[1],group:s[2],desc:s[3],mark:s[4],art:s[5],color:s[6],folder:folders[Math.min(3,groups.indexOf(s[2]))],manual:i===2});
const tabs=seed.map((r,i)=>make(r,i,'t')),bookmarks=seed.slice(0,12).map((r,i)=>make(r,i,'b')),history=seed.slice(0,9).map((r,i)=>({...make(r,i,'h'),group:i>5?'待整理':r[2]}));
bookmarks.push(make(['Color field · 自然的配色','color.example','设计与造物','从植物、岩石与日光里采集颜色。','C','poster','#927557'],12,'b'),make(['SVG handbook · 让图形呼吸','svg.example','代码与逻辑','向量、曲线与那些轻巧的交互。','S','grid','#76835c'],13,'b'),{...make(seed[12],14,'b'),folder:folders[2]},{...make(seed[0],15,'b'),folder:folders[2],desc:'同一网址的另一份收藏，保留它在原目录中的位置。'});
const state={mode:'bookmarks',tabs:{view:'workspace',filter:'全部',q:'',layout:'list',selected:'t0',scroll:0},bookmarks:{view:'folders',filter:'全部',q:'',layout:'list',selected:'b0',scroll:0},night:false,appearance:'system',previewEnabled:true,reviewBy:'group',date:'2026-10-12',hour:10};
const cur=()=>state[state.mode],all=()=>state.mode==='bookmarks'?bookmarks:cur().view==='history'?history:tabs,find=id=>[...tabs,...bookmarks,...history].find(r=>r.id===id),key=()=>state.mode==='bookmarks'&&cur().view==='folders'?'folder':'group';
const rows=()=>all().filter(r=>cur().q?`${r.title} ${r.domain} ${r.group} ${r.folder}`.toLowerCase().includes(cur().q.toLowerCase()):cur().filter==='全部'||r[key()]===cur().filter).filter(()=>cur().view!=='history'||state.date==='2026-10-12');
let hoverTimer,toastTimer,previewTrigger,activeId=null;
const rules=[{domain:'figma.com',group:groups[0],mode:'tabs',enabled:true},{domain:'developer.mozilla.org',group:groups[1],mode:'tabs',enabled:true},{domain:'type.example',group:groups[0],mode:'bookmarks',enabled:true}];
$('#search').insertAdjacentHTML('afterbegin',I('search'));$('#menu').innerHTML=I('menu');$('#theme').innerHTML=I('moon');$('#settings').innerHTML=I('settings');$('#rail-about').innerHTML=I('info');$('#rail-close').innerHTML=I('close');$('#search-glyph').innerHTML=I('search');$('#command-close').innerHTML=I('close');
function transition(fn){if(document.startViewTransition&&!matchMedia('(prefers-reduced-motion:reduce)').matches)document.startViewTransition(fn);else fn();}
function navItem(label,ico,attr,value,active,count){return `<button class="nav ${active?'active':''}" data-${attr}="${E(value)}" ${active?'aria-current="page"':''}>${I(ico)}<span>${E(label)}</span>${count===undefined?'':`<span class="number mono">${String(count).padStart(2,'0')}</span>`}</button>`}
function renderNav(){
 const t=state.mode==='tabs',v=cur().view;
 let html='<div class="nav-group"><p class="rail-label mono">'+(t?'01 / BROWSING':'02 / COLLECTION')+'</p>';
 if(t)html+=navItem('工作区','tabs','view','workspace',v==='workspace',tabs.length)+navItem('每日回顾','clock','view','review',v==='review')+navItem('继续浏览','history','view','history',v==='history',history.length);
 else html+=navItem('原文件夹','folder','view','folders',v==='folders',bookmarks.length)+navItem('智能分类','spark','view','smart',v==='smart');
 html+='</div>';
 if(!['review','settings','manage','rules'].includes(v)){
  const folder=key()==='folder',list=all();
  html+='<div class="nav-group"><p class="rail-label mono">'+(folder?'COLLECTIONS / 目录':'YOUR SPACES / 分类')+'</p>'+navItem('全部','all','filter','全部',cur().filter==='全部',list.length);
  (folder?folders:groups).forEach(name=>{const count=list.filter(r=>r[key()]===name).length;if(count)html+=navItem(folder?name.split(' / ')[1]:name,'folder','filter',name,cur().filter===name,count);});html+='</div>';
 }
 html+='<div class="nav-group management"><p class="rail-label mono">ORGANIZE / 管理</p>'+navItem('工作区管理','grid','view','manage',v==='manage')+navItem('分类规则','spark','view','rules',v==='rules')+navItem('设置与隐私','settings','view','settings',v==='settings')+'</div>';
 $('#nav').innerHTML=html;
}
function render(){
 clearHover();renderNav();closePreview();
 $$('[data-mode]').forEach(b=>{b.classList.toggle('active',b.dataset.mode===state.mode);b.setAttribute('aria-pressed',b.dataset.mode===state.mode);b.querySelector('sup').textContent=b.dataset.mode==='tabs'?tabs.length:bookmarks.length;});
 const t=state.mode==='tabs',v=cur().view,h=v==='history',review=v==='review';
 const titles={workspace:'WORK<br>SPACE.',review:'DAILY<br>REVIEW.',history:'PICK UP<br>THE THREAD.',folders:'BOOK<br>MARKS.',smart:'SMART<br>COLLECTION.',manage:'YOUR<br>SPACES.',rules:'SET<br>THE RULES.',settings:'MAKE<br>IT YOURS.'};
 const subtitles={workspace:'标签工作区',review:'每日回顾',history:'继续浏览',folders:'书签 · 原文件夹',smart:'书签 · 智能分类',manage:'工作区管理',rules:'分类规则',settings:'设置与隐私'};
 const count=String(review?154:v==='manage'?groups.length:v==='rules'?rules.filter(r=>r.mode===state.mode).length:v==='settings'?3:rows().length).padStart(2,'0');
 const countLabel=review?'MINUTES':v==='manage'?'SPACES':v==='rules'?'RULES':v==='settings'?'EDITION':'SAVED PAGES';
 let html='<div class="eyebrow mono"><span>03 / OFFSET — '+(t?'TABS':'BOOKMARKS')+'</span><span>交互原型 · 模拟数据</span></div><section class="hero"><div class="hero-text"><h1>'+titles[v]+'</h1><p class="hero-sub"><span class="dash"></span>'+subtitles[v]+'</p></div><div class="hero-stat"><strong>'+count+'</strong><span class="mono">'+countLabel+'</span></div></section>';
 if(['settings','manage','rules'].includes(v)){html+=v==='settings'?settingsHTML():v==='manage'?manageHTML():rulesHTML();$('#workspace').innerHTML=html+footer();return;}
 if(review){$('#workspace').innerHTML=html+reviewHTML()+footer();bindHover();return;}
 const visible=rows(),pending=visible.filter(r=>r.group==='待整理'&&!r.manual).length;
 html+='<div class="summary-strip"><span class="summary-copy">'+I(h?'history':t?'tabs':v==='folders'?'folder':'spark')+'<span>'+(h?'保留已有分类与人工调整':t?'给正在进行的事，一个位置':v==='folders'?'沿用原文件夹的收藏秩序':'按主题整理，保留原目录')+'</span><span class="subtle mono">'+pending+' 待整理</span></span><button class="text-button" data-action="classify">'+(h?'历史补分类':'整理待分类')+I('arrow')+'</button></div>';
 if(!visible.some(r=>r.id===cur().selected))cur().selected=visible[0]?.id||null;
 html+='<div class="stage"><section class="index" aria-label="'+(t?'标签':'书签')+'列表"><div class="list-tools"><div class="scope"><strong>'+(cur().q?'搜索结果':E(cur().filter==='全部'?(h?'历史工作现场':t?'全部标签':'全部书签'):cur().filter.split(' / ').at(-1)))+'</strong><span class="mono">/ '+String(visible.length).padStart(2,'0')+'</span></div><div class="view-controls">'+(h?'<input class="date-picker" id="date" type="date" value="'+state.date+'" max="2026-10-13" aria-label="历史日期"><button class="button compact" data-action="restore">恢复清单 '+I('refresh')+'</button>':'<button class="tool '+(cur().layout==='list'?'active':'')+'" data-layout="list" aria-label="索引列表" aria-pressed="'+(cur().layout==='list')+'">'+I('list')+'</button><button class="tool '+(cur().layout==='gallery'?'active':'')+'" data-layout="gallery" aria-label="预览画廊" aria-pressed="'+(cur().layout==='gallery')+'">'+I('grid')+'</button>')+'</div></div>';
 if(cur().q)html+='<div class="search-state"><span>“'+E(cur().q)+'” · 当前面板全部内容</span><button data-action="clear-search">清除 ×</button></div>';
 if(!visible.length)html+='<div class="empty"><p>NOTHING HERE.</p><span>'+(h?'这个日期没有模拟记录，试试 10 月 12 日。':'没有匹配结果，换个关键词试试。')+'</span><button class="button" data-action="reset-filter">返回全部</button></div>';
 else if(cur().layout==='gallery'&&!h)html+='<div class="gallery">'+visible.map(r=>'<button class="gallery-card" data-select="'+r.id+'" aria-label="预览 '+E(r.title)+'"><div class="gallery-art">'+art(r)+'</div><div class="gallery-copy"><strong>'+E(r.title)+'</strong><span>'+E(r.group)+' · '+E(r.domain)+'</span></div></button>').join('')+'</div>';
 else {html+='<div class="column-head mono"><span>来源 / SOURCE</span><span>页面 / PAGE</span><span>分类 / GROUP</span></div>';html+=visible.map((r,i)=>rowHTML(r,i+1)).join('');}
 html+='<p class="list-footnote">'+I('eye')+'悬停查看网页缩略图 · 点击眼睛可固定预览</p></section>'+inspectorShell()+'</div>';
 $('#workspace').innerHTML=html+footer();bindHover();if($('#date'))$('#date').onchange=e=>{state.date=e.target.value;render();};
}
function rowHTML(r,i){
 return '<div class="item" data-row="'+r.id+'"><div class="row-origin"><span class="row-origin-text"><span class="item-number mono">'+String(i).padStart(2,'0')+'</span><strong>'+E(r.domain.split('.')[0])+'</strong></span></div><div class="row-stripes" aria-hidden="true">'+Array.from({length:12},(_,n)=>'<i style="--weight:'+1/(n+2)+';--delay:'+(180+n*12)+'ms"></i>').join('')+'</div><div class="row-details"><button class="item-main" data-open="'+r.id+'"><span class="item-title">'+E(r.title)+(r.manual?'<span class="manual-tag">手动</span>':'')+'</span><span class="item-meta">'+E(state.mode==='bookmarks'&&cur().view==='folders'?r.folder:r.domain)+'</span></button><span class="row-group">'+E(r.group)+'</span><span class="item-actions"><button class="tool preview-button" data-select="'+r.id+'" aria-label="预览 '+E(r.title)+'">'+I('eye')+'</button><button class="tool arrow-action" data-detail="'+r.id+'" aria-label="调整 '+E(r.title)+' 的分类">'+I('more')+'</button></span></div></div>';
}

function footer(){return '<footer class="app-footer"><span>拾页 / TABKEEP</span><span class="mono">OFFSET · 模拟数据 · '+(state.mode==='tabs'?'BROWSING':'COLLECTIONS')+'</span><a href="index.html">四版对比 ↗</a></footer>';}

const esc=E;
  function specimenArtwork(item) {
    const head = `<text x="28" y="32" font-size="13" font-weight="700">${esc(item.site.toUpperCase())}</text><text x="518" y="32" font-size="9" letter-spacing="1">INDEX / 2026</text><path d="M28 48H612" stroke="currentColor" stroke-opacity=".22"/>`;
    const compositions = {
      forma:`<rect width="640" height="420" fill="#ecdcdf"/><g fill="#8c2638">${head}<text x="27" y="143" font-size="83" font-weight="900" letter-spacing="-6">FORM</text><text x="27" y="226" font-size="83" font-weight="900" letter-spacing="-6">&amp; FEEL.</text><text x="30" y="285" font-size="11" letter-spacing="2">A STUDY IN SHAPE &amp; SENSATION</text><text x="30" y="386" font-size="10">SELECTED OBJECTS — NO. 028</text></g><ellipse cx="464" cy="352" rx="106" ry="15" fill="#a24d5b" opacity=".15"/><path d="M389 342V206a76 76 0 0 1 152 0v136h-46V206a30 30 0 0 0-60 0v136z" fill="#b7444d"/><path d="M389 342V206a76 76 0 0 1 117-64 76 76 0 0 0-97 72v128z" fill="#d76b70"/><circle cx="464" cy="300" r="35" fill="#7e2c3f"/><path d="M509 343V206a50 50 0 0 0-19-40" fill="none" stroke="#cc6669" stroke-width="5"/>`,
      orbit:`<rect width="640" height="420" fill="#193dde"/><g fill="#f2f5ff">${head}<text x="27" y="172" font-size="116" font-weight="800" letter-spacing="-8">ORBIT</text><text x="30" y="387" font-size="10" letter-spacing="2">INDEPENDENT BY DESIGN.</text></g><circle cx="450" cy="292" r="102" fill="#d9ecff"/><ellipse cx="450" cy="291" rx="161" ry="36" fill="none" stroke="#8daefb" stroke-width="12" transform="rotate(-24 450 291)"/><circle cx="313" cy="358" r="16" fill="#f9bd82"/><text x="30" y="259" fill="#c6d8ff" font-size="12">NEW IDEAS.</text><text x="30" y="279" fill="#c6d8ff" font-size="12">DIFFERENT ORBITS.</text>`,
      type:`<rect width="640" height="420" fill="#efeeeb"/><g fill="#252324">${head}<text x="24" y="320" font-family="Georgia,serif" font-size="295" letter-spacing="-25">Ag</text><text x="447" y="135" font-size="12">LETTERS</text><text x="447" y="153" font-size="12">WITH</text><text x="447" y="171" font-size="12">CHARACTER.</text><text x="28" y="391" font-size="10" letter-spacing="2">TYPE SPECIMEN — 001</text></g><path d="M25 325H610M435 66V350" stroke="#f1472f"/><circle cx="436" cy="325" r="5" fill="#f1472f"/>`,
      field:`<rect width="640" height="420" fill="#b8c0d9"/><g fill="#283342">${head}</g><circle cx="441" cy="143" r="48" fill="#f9f1e0"/><path d="m0 329 133-171 160 105 167-91 180 89v159H0z" fill="#7b8cab"/><path d="m0 360 242-124 99 91 125-67 174 104v56H0z" fill="#536b87"/><path d="m0 385 177-43 95 37 368-50v91H0z" fill="#394f6f"/><text x="27" y="139" fill="#26354c" font-size="63" font-weight="700" letter-spacing="-3">Out of office.</text><text x="29" y="390" fill="#fff" font-size="11" letter-spacing="2">FIELD NOTES / THE LONG WAY HOME</text>`,
      grid:`<rect width="640" height="420" fill="#edf2ff"/><g stroke="#c4d0ed" stroke-width="1">${Array.from({length:13},(_,i)=>`<path d="M${i*50} 55v340"/>`).join('')}${Array.from({length:7},(_,i)=>`<path d="M20 ${80+i*50}H620"/>`).join('')}</g><g fill="#244ac5">${head}<rect x="50" y="80" width="200" height="150" rx="3"/><rect x="270" y="80" width="130" height="70" rx="3"/><rect x="270" y="170" width="280" height="60" rx="3"/><text x="46" y="333" font-size="67" font-weight="800" letter-spacing="-4">Good structure.</text><text x="50" y="379" font-size="11" letter-spacing="2">ROOM FOR EVERYTHING.</text></g><rect x="420" y="80" width="130" height="70" rx="3" fill="#7c9aec"/>`,
      objects:`<rect width="640" height="420" fill="#e9d6c9"/><g fill="#744834">${head}<text x="26" y="135" font-size="72" font-weight="400" letter-spacing="-4">Ordinary,</text><text x="28" y="204" font-size="72" font-weight="400" letter-spacing="-4">beautiful.</text><text x="30" y="388" font-size="10" letter-spacing="2">OBJECTS / EVERYDAY STUDIES</text></g><ellipse cx="460" cy="349" rx="99" ry="13" fill="#93634e" opacity=".17"/><path d="M421 189h66v24c0 30 46 42 46 85 0 30-27 51-77 51s-76-19-76-51c0-44 41-55 41-85z" fill="#af6e50"/><path d="M434 199v33c0 27-26 44-26 72 0 13 9 26 18 33" fill="none" stroke="#d29979" stroke-width="16"/><ellipse cx="454" cy="190" rx="33" ry="8" fill="#7a432f"/>`,
      margins:`<rect width="640" height="420" fill="#e7e3ed"/><g fill="#4c3c63">${head}<text x="29" y="132" font-size="54" font-weight="500" letter-spacing="-3">Room to</text><text x="29" y="188" font-size="54" font-weight="500" letter-spacing="-3">think again.</text><text x="31" y="224" font-size="10" letter-spacing="2">ESSAYS FROM THE EDGES</text><text x="31" y="388" font-size="10">READ SLOWLY. KEEP SOMETHING.</text></g><rect x="368" y="89" width="196" height="264" fill="#f9f7fc" transform="rotate(7 466 221)"/><rect x="361" y="93" width="196" height="264" fill="#fcfbfd"/><g stroke="#c7bfce" stroke-width="3">${Array.from({length:12},(_,i)=>`<path d="M390 ${142+i*14}h137"/>`).join('')}</g><rect x="390" y="114" width="63" height="9" fill="#6c588a"/>`,
      motion:`<rect width="640" height="420" fill="#fa573c"/><g fill="#4a1b18">${head}<text x="26" y="136" font-size="72" font-weight="900" letter-spacing="-5">IN MOTION.</text><text x="30" y="388" font-size="10" letter-spacing="2">MOVE WITH INTENTION.</text></g>${Array.from({length:6},(_,i)=>`<rect x="${120+i*62}" y="${192+i*9}" width="90" height="112" rx="44" fill="${['#64271f','#813325','#a2402b','#c64d30','#ec603b','#ffb390'][i]}" transform="rotate(-28 ${165+i*62} ${248+i*9})"/>`).join('')}`
    };
    return `<svg viewBox="0 0 640 420" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${esc(item.site)} 的模拟网页缩略图" font-family="Arial, Helvetica, sans-serif" style="color:#333">${compositions[item.art]}</svg>`;
  }

function art(r){if(!r?.art)return '<div class="placeholder-art"><span class="mono">NO PREVIEW YET</span><strong>这一页，<br>等你再回来。</strong><p>暂无预览 · '+E(r?.domain||'未选择页面')+'</p></div>';const map={poster:'forma',design:'orbit',objects:'objects',type:'type',code:'grid',grid:'grid',landscape:'field',article:'margins'};return specimenArtwork({site:r.title.split(/[·—]/)[0].trim(),art:map[r.art]||'forma'});}

function inspectorShell(){return '<aside class="inspector" id="inspector" aria-hidden="true" aria-label="模拟网页缩略图"></aside>';}
function renderInspector(){
 const panel=$('#inspector'),r=find(activeId);if(!panel||!r)return;
 panel.innerHTML='<div class="floating-art">'+art(r)+'</div><div class="floating-caption"><span>'+E(r.domain)+'</span><span>示意缩略图 / '+r.id.toUpperCase()+'</span></div>';positionPreview();
}
function positionPreview(){
 const panel=$('#inspector'),stage=$('.stage');if(!panel||!stage||!activeId||innerWidth<=700)return;
 const box=stage.getBoundingClientRect(),width=Math.min(480,box.width*.47),height=width*420/640+30,bar=$('.topbar').getBoundingClientRect().bottom;
 if(box.bottom<bar+80||box.top>innerHeight-60){clearHover();return;}
 const top=Math.min(innerHeight-height-20,Math.max(box.top+40,Math.min(box.bottom-20,innerHeight-20)-height));
 panel.style.width=width+'px';panel.style.left=(box.right-width)+'px';panel.style.top=Math.max(bar+8,top)+'px';
}
function select(id,explicit=false,trigger=null){
 if(explicit){clearHover();const r=find(id);if(!r)return;cur().selected=id;modal('页面预览','<div class="detail-art">'+art(r)+'</div><p class="dialog-copy" style="font-size:15px;color:var(--ink)">'+E(r.title)+'</p><p class="dialog-copy">'+E(r.desc)+'</p><div class="dialog-strip">'+E(r.domain)+' · 模拟网页缩略图</div>','<button class="button" data-detail="'+r.id+'">调整分类</button><button class="button primary" data-open="'+r.id+'">打开演示 '+I('arrow')+'</button>');return;}
 cur().selected=id;activeId=id;renderInspector();$('#inspector')?.classList.add('is-visible');$('#inspector')?.setAttribute('aria-hidden','false');
}
function clearHover(){
 clearTimeout(hoverTimer);activeId=null;$$('.item.is-hovered').forEach(r=>r.classList.remove('is-hovered'));const p=$('#inspector');if(p){p.classList.remove('is-visible');p.setAttribute('aria-hidden','true');}
}
function closePreview(){clearHover();$('#preview-overlay').classList.remove('show');}

$('#preview-overlay').onclick=closePreview;
function bindHover(){
 $$('[data-row]').forEach(row=>{
  const enter=()=>{if(activeId===row.dataset.row)return;clearHover();row.classList.add('is-hovered');activeId=row.dataset.row;
   if(!state.previewEnabled||innerWidth<=700)return;
   const id=activeId;hoverTimer=setTimeout(()=>{if(activeId===id&&row.isConnected&&!$('#dialog').open&&!$('#command').open)select(id);},matchMedia('(prefers-reduced-motion:reduce)').matches?0:480);
  };
  row.onmouseenter=()=>{if(matchMedia('(hover:hover)').matches)enter();};
  row.onmouseleave=()=>{if(activeId===row.dataset.row&&!row.querySelector(':focus-visible'))clearHover();};
  row.addEventListener('focusin',e=>{if(e.target.matches(':focus-visible'))enter();});
  row.addEventListener('focusout',e=>{if(!row.contains(e.relatedTarget)&&activeId===row.dataset.row)clearHover();});
 });
}

function reviewHTML(){
 const values=[68,42,28,16],colors=['#ff4b22','#171717','#787b83','#c7c9d0'],labels=state.reviewBy==='site'?['figma.com','github.com','field.example','其他网站']:groups.slice(0,4);
 return '<div class="summary-strip"><span class="summary-copy">'+I('clock')+'14 个页面 / 24 段浏览片段</span><span class="mono">2026.10.13</span></div><div class="review-layout"><section class="review-panel"><div class="section-heading"><h2>时间分布</h2><div class="segmented"><button data-review-by="site" aria-pressed="'+(state.reviewBy==='site')+'">网站</button><button data-review-by="group" aria-pressed="'+(state.reviewBy==='group')+'">工作区</button></div></div><p class="review-value">2<small>h</small> 34<small>min</small></p><p class="review-sub">浏览投入 · 模拟估算</p><div class="distribution">'+values.map((v,i)=>'<span style="width:'+v/154*100+'%;background:'+colors[i]+'"></span>').join('')+'</div>'+values.map((v,i)=>'<p class="legend"><span><i style="--tone:'+colors[i]+'"></i>'+labels[i]+'</span><span class="mono">'+v+' min</span></p>').join('')+'</section><section class="review-panel"><div class="section-heading"><h2>一天的节奏</h2><span class="mono muted">每格 1 小时</span></div><p class="review-value">'+String(state.hour).padStart(2,'0')+'<small>:00</small></p><p class="review-sub">选择时段，回看浏览路径</p><div class="bars">'+[12,21,72,100,34,9,48,76,29,17,9,2].map((v,i)=>'<button class="bar '+(state.hour===i+7?'active':'')+'" data-hour="'+(i+7)+'" style="height:'+v+'%" aria-label="查看 '+(i+7)+' 点浏览路径" aria-pressed="'+(state.hour===i+7)+'"></button>').join('')+'</div><div class="bar-axis mono"><span>07:00</span><span>12:00</span><span>18:00</span></div><p class="review-note">空白时间不补记。</p></section></div><div class="stage timeline"><section class="index"><div class="list-tools"><strong>浏览路径</strong><span class="mono">'+state.hour+':00 — '+(state.hour+1)+':00</span></div>'+[tabs[state.hour%6],tabs[(state.hour+1)%6],tabs[(state.hour+2)%6]].map((r,i)=>'<div class="timeline-step"><time class="mono">'+state.hour+':'+['04','19','42'][i]+'</time>'+rowHTML(r,i+1)+'</div>').join('')+'</section>'+inspectorShell()+'</div>';
}

function toast(msg){clearTimeout(toastTimer);$('#toast').textContent=msg;$('#toast').hidden=false;toastTimer=setTimeout(()=>$('#toast').hidden=true,3400);}
function modal(title,body,actions=''){clearTimeout(hoverTimer);closePreview();$('#dialog').innerHTML=`<div class="dialog-shell"><div class="dialog-kicker mono">TABKEEP / INTERACTION STUDY</div><div class="dialog-heading"><h2>${title}</h2><button class="tool" data-close aria-label="关闭对话框">${I('close')}</button></div>${body}<div class="dialog-actions">${actions||'<button class="button primary" data-close>明白了</button>'}</div></div>`;if(!$('#dialog').open)$('#dialog').showModal();$('#dialog [data-close]').focus();}
function openPage(r){modal('把这条思路，接下去。',`<p class="dialog-copy" style="color:var(--ink);font-size:15px">${E(r.title)}</p><p class="dialog-copy mono" style="font-size:10px;margin-top:5px">${E(r.domain)}</p><div class="dialog-strip">实际插件会打开页面，或切换至已有标签。<br>这份独立原型只演示交互，不访问目标网站。</div>`);}
function detail(r){modal('让它有一个位置。',`<p class="dialog-copy">${E(r.title)}</p>${r.id.startsWith('b')?`<div class="dialog-strip">原文件夹：${E(r.folder)}<br>调整智能分类不会移动这条书签。</div>`:''}<label class="field">${r.id.startsWith('b')?'智能分类':'所属工作区'}<select id="group-select">${groups.map(g=>`<option ${r.group===g?'selected':''}>${g}</option>`).join('')}</select></label><p class="dialog-copy" style="font-size:10px;margin-top:14px">人工调整会保留；刷新原型后恢复初始模拟数据。</p>`,`<button class="button" data-close>取消</button><button class="button primary" id="save-group">保存分类 ${I('right')}</button>`);$('#save-group').onclick=()=>{r.group=$('#group-select').value;if(r.id.startsWith('h'))r.snapshotGroup=r.group;r.manual=true;$('#dialog').close();render();toast('已保存模拟分类 · 原文件夹不变');};}
function classify(){const candidates=rows().filter(r=>r.group==='待整理'&&!r.manual);if(!candidates.length){toast('当前范围已经整理好，人工分类保持不变。');return;}modal(cur().view==='history'?'把遗漏的灵感，归回原处。':'为新的灵感，建立索引。',`<p class="dialog-copy">只处理当前范围中的 ${candidates.length} 条待整理记录。已有分类、人工调整${state.mode==='bookmarks'?'与原文件夹':''}保持不变。</p><div class="dialog-strip">${candidates.map(r=>E(r.title)).join('<br>')}</div><label class="check-line"><input type="checkbox" id="ai-demo">演示 AI 辅助分类</label><p class="dialog-copy" style="font-size:10px;margin-top:13px">原型仅演示结果，不调用 AI，也不发送数据。</p>`,`<button class="button" data-close>暂时放着</button><button class="button primary" id="classify-confirm">开始整理 ${I('spark')}</button>`);$('#classify-confirm').onclick=()=>{candidates.forEach((r,i)=>{r.group=rules.find(rule=>rule.enabled&&rule.mode===state.mode&&r.domain.includes(rule.domain))?.group||groups[i%3];if(cur().view==='history')r.snapshotGroup=r.group;});$('#dialog').close();if(state.mode==='bookmarks'){cur().view='smart';cur().filter='全部';}render();toast(`已整理 ${candidates.length} 条模拟记录 · 人工调整保留`);};}
function applyTheme(){state.night=state.appearance==='dark'||state.appearance==='system'&&matchMedia('(prefers-color-scheme:dark)').matches;document.documentElement.classList.toggle('night',state.night);$('#theme').innerHTML=I(state.night?'sun':'moon');$('#theme').setAttribute('aria-label',state.night?'切换浅色主题':'切换深色主题');}
function theme(){state.appearance=state.night?'light':'dark';applyTheme();if(cur().view==='settings')render();}
function settings(){cur().view='settings';cur().q='';render();closeRail();window.scrollTo(0,0);}
function settingsHTML(){return '<div class="settings-grid"><section class="settings-section"><div class="section-heading"><h2>界面与交互</h2><span class="mono">01 / APPEARANCE</span></div><div class="setting-row"><div><strong>外观</strong><p>黑白的秩序，橙色的焦点。</p></div><div class="segmented">'+[['system','跟随系统'],['light','浅色'],['dark','深色']].map(([key,label])=>'<button data-appearance="'+key+'" aria-pressed="'+(state.appearance===key)+'">'+label+'</button>').join('')+'</div></div><div class="setting-row"><div><strong>悬停缩略图</strong><p>条纹反色之后，展示对应页面。</p></div><button class="toggle" data-preview-toggle aria-pressed="'+state.previewEnabled+'" aria-label="悬停缩略图">'+(state.previewEnabled?'开启':'关闭')+'</button></div><div class="setting-row"><div><strong>减少动态效果</strong><p>跟随系统偏好，保留静态反色与预览。</p></div><span class="muted">'+(matchMedia('(prefers-reduced-motion:reduce)').matches?'已开启':'跟随系统')+'</span></div></section><section class="settings-section"><div class="section-heading"><h2>AI 与隐私</h2><span class="mono">02 / PRIVACY</span></div><div class="setting-row"><div><strong>分类方式</strong><p>先使用规则，再演示补分类。</p></div><span class="status-chip">模拟模式</span></div><div class="setting-row"><div><strong>书签与标签分开处理</strong><p>已有分类、原文件夹和人工调整保留。</p></div>'+I('lock')+'</div><div class="setting-row"><div><strong>预览来源</strong><p>内置示意图，不采集真实网页。</p></div><span class="muted">本地演示</span></div></section></div><div class="settings-note"><p>完整设计原型 · 所有操作只改变当前页面中的模拟数据。</p><button class="button" data-reset-demo>重置演示 '+I('refresh')+'</button></div>';}
function manageHTML(){return '<div class="list-tools"><strong>你的工作区</strong><button class="button primary" data-add-group>新建工作区 ＋</button></div><div class="management-list">'+groups.filter(g=>g!=='待整理').map((g,i)=>'<div class="management-row"><span class="management-number mono">'+String(i+1).padStart(2,'0')+'</span><div><h2>'+E(g)+'</h2><p>'+tabs.filter(r=>r.group===g).length+' 个标签 · '+bookmarks.filter(r=>r.group===g).length+' 个书签</p></div><button class="button" data-edit-group="'+E(g)+'">重命名 '+I('arrow')+'</button></div>').join('')+'</div><p class="management-note">工作区用于组织内容，书签的原文件夹单独保留。</p>';}
function rulesHTML(){const current=rules.filter(r=>r.mode===state.mode);return '<div class="summary-strip"><span>规则范围：'+(state.mode==='tabs'?'标签页与历史记录':'书签智能分类')+'</span><button class="button primary" data-add-rule>新建规则 ＋</button></div><div class="management-list">'+(current.length?current.map(r=>'<div class="management-row"><span class="rule-domain mono">'+E(r.domain)+'</span><div><h2>'+E(r.group)+'</h2><p>网站匹配 · 仅处理待整理内容</p></div><button class="toggle" data-rule-toggle="'+rules.indexOf(r)+'" aria-pressed="'+r.enabled+'">'+(r.enabled?'开启':'关闭')+'</button></div>').join(''):'<div class="empty"><p>还没有规则</p><span>添加一条网站规则，让新内容自动归位。</span></div>')+'</div><p class="management-note">规则不会覆盖手动分类。这里仅演示规则配置与分类结果。</p>';}
function editGroup(oldName=''){modal(oldName?'重命名工作区':'新建工作区','<label class="field">工作区名称<input id="group-name" value="'+E(oldName)+'" maxlength="30" autocomplete="off"></label>','<button class="button" data-close>取消</button><button class="button primary" id="confirm-group">保存</button>');$('#confirm-group').onclick=()=>{const input=$('#group-name'),name=input.value.trim();if(!name||groups.some(g=>g===name&&g!==oldName)){input.setCustomValidity('请输入一个不重复的名称');input.reportValidity();return;}input.setCustomValidity('');if(oldName){groups[groups.indexOf(oldName)]=name;[...tabs,...bookmarks,...history].forEach(r=>{if(r.group===oldName)r.group=name;if(r.snapshotGroup===oldName)r.snapshotGroup=name;});rules.forEach(r=>{if(r.group===oldName)r.group=name;});['tabs','bookmarks'].forEach(mode=>{if(state[mode].filter===oldName)state[mode].filter=name;});}else groups.splice(groups.length-1,0,name);$('#dialog').close();render();toast('工作区已保存');};$('#group-name').oninput=e=>e.target.setCustomValidity('');}
function addRule(){modal('新建分类规则','<label class="field">匹配网站<input id="rule-domain" placeholder="例如 new.example" maxlength="120" autocomplete="off"></label><label class="field">归入分类<select id="rule-group">'+groups.filter(g=>g!=='待整理').map(g=>'<option>'+E(g)+'</option>').join('')+'</select></label>','<button class="button" data-close>取消</button><button class="button primary" id="confirm-rule">保存规则</button>');$('#confirm-rule').onclick=()=>{const input=$('#rule-domain'),domain=input.value.trim().toLowerCase();if(!/^[a-z0-9.-]+\.[a-z]{2,}$/.test(domain)){input.setCustomValidity('请输入域名，例如 new.example');input.reportValidity();return;}rules.push({domain,group:$('#rule-group').value,mode:state.mode,enabled:true});$('#dialog').close();render();toast('已保存模拟规则');};$('#rule-domain').oninput=e=>e.target.setCustomValidity('');}

function search(){clearTimeout(hoverTimer);closePreview();$('#query').value=cur().q;$('#command').showModal();searchResults();$('#query').focus();}
function searchResults(){const q=$('#query').value.trim().toLowerCase(),list=all().filter(r=>`${r.title} ${r.domain} ${r.group} ${r.folder}`.toLowerCase().includes(q));$('#search-output').innerHTML=list.length?list.slice(0,9).map((r,i)=>`<button class="search-result" data-result="${r.id}"><span class="mono muted">${String(i+1).padStart(2,'0')}</span><div><strong>${E(r.title)}</strong><small>${E(state.mode==='bookmarks'?r.folder:r.group)} · ${E(r.domain)}</small></div>${I('arrow')}</button>`).join(''):'<div class="empty"><p class="serif">Not here. Yet.</p><p>没有找到匹配内容，试试“设计”或“GitHub”。</p></div>';}
$('#query').oninput=searchResults;$('#query').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();e.stopPropagation();cur().q=e.target.value.trim();if(['review','settings','manage','rules'].includes(cur().view))cur().view=state.mode==='tabs'?'workspace':'folders';$('#command').close();render();}};$('#command-close').onclick=()=>$('#command').close();$('#search').onclick=search;
function railAccess(){$('#rail').inert=innerWidth<=800&&!$('#rail').classList.contains('open');$('#rail').setAttribute('aria-hidden',$('#rail').inert);}
function closeRail(){const opened=$('#rail').classList.contains('open');$('#rail').classList.remove('open');$('#rail-overlay').hidden=true;$('#menu').setAttribute('aria-expanded','false');railAccess();if(opened)$('#menu').focus();}
$('#menu').onclick=()=>{$('#rail').classList.add('open');$('#rail-overlay').hidden=false;$('#menu').setAttribute('aria-expanded','true');railAccess();$('#rail .nav').focus();};$('#rail-close').onclick=closeRail;$('#rail-overlay').onclick=closeRail;$('#theme').onclick=theme;$('#settings').onclick=settings;$('#rail-about').onclick=settings;
$('#brand').onclick=()=>{state.mode='tabs';state.tabs.view='workspace';state.tabs.filter='全部';state.tabs.q='';render();closeRail();window.scrollTo(0,0);};
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
 if(b.dataset.mode){closePreview();cur().scroll=scrollY;state.mode=b.dataset.mode;transition(()=>{render();window.scrollTo(0,cur().scroll);});}
 else if(b.dataset.view){closePreview();cur().view=b.dataset.view;cur().filter='全部';cur().q='';transition(render);closeRail();window.scrollTo(0,0);}
 else if(b.dataset.filter){closePreview();cur().filter=b.dataset.filter;cur().q='';render();closeRail();window.scrollTo(0,0);}
 else if(b.dataset.layout){cur().layout=b.dataset.layout;transition(render);}
 else if(b.dataset.select){select(b.dataset.select,true,b);}
 else if(b.dataset.detail){detail(find(b.dataset.detail));}
 else if(b.dataset.open){openPage(find(b.dataset.open));}
 else if(b.dataset.hour){state.hour=Number(b.dataset.hour);render();}
 else if(b.dataset.result){const r=find(b.dataset.result);$('#command').close();detail(r);}
 else if(b.hasAttribute('data-close'))$('#dialog').close();
 else if(b.dataset.themeChoice){const night=b.dataset.themeChoice==='dark';if(night!==state.night)theme();b.parentElement.querySelectorAll('button').forEach(x=>x.classList.toggle('active',x===b));}
 else if(b.dataset.action){const a=b.dataset.action;if(a==='classify')classify();else if(a==='clear-search'){cur().q='';render();}else if(a==='reset-filter'){cur().q='';cur().filter='全部';if(cur().view==='history')state.date='2026-10-12';render();}else if(a==='restore'){if(!rows().length){toast('这个日期没有可以恢复的模拟页面。');return;}modal('重新走进，那一天。','<p class="dialog-copy">恢复当前清单中的页面，复用已经打开的标签，并保留历史分类。</p><div class="dialog-strip">此处是恢复演示，不会实际打开网页。</div>','<button class="button" data-close>取消</button><button class="button primary" id="restore-confirm">演示恢复 '+I('arrow')+'</button>');$('#restore-confirm').onclick=()=>{let added=0;rows().forEach(r=>{if(!tabs.some(t=>t.domain===r.domain&&t.title===r.title)){tabs.push({...r,id:'restored-'+r.id,group:r.snapshotGroup||r.group,manual:true});added++;}});$('#dialog').close();render();toast('模拟恢复完成 · 新增 '+added+' 页，已有标签已复用');};}}
});
document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();if(!$('#dialog').open)search();}if(e.key==='Escape'){closePreview();closeRail();}if(e.key==='Tab'){const p=$('#inspector.mobile-open')||$('#rail.open');if(p){const focusable=[...p.querySelectorAll('button:not(:disabled),input,select')].filter(x=>x.offsetParent!==null);const first=focusable[0],last=focusable.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}}});
window.addEventListener('resize',()=>{if(innerWidth>800)closeRail();if(innerWidth>620)closePreview();railAccess();});
document.addEventListener('click',e=>{
 const b=e.target.closest('button');if(!b)return;
 if(b.dataset.reviewBy){state.reviewBy=b.dataset.reviewBy;render();}
 else if(b.dataset.appearance){state.appearance=b.dataset.appearance;applyTheme();render();}
 else if(b.hasAttribute('data-preview-toggle')){state.previewEnabled=!state.previewEnabled;render();}
 else if(b.hasAttribute('data-add-group'))editGroup();
 else if(b.dataset.editGroup)editGroup(b.dataset.editGroup);
 else if(b.hasAttribute('data-add-rule'))addRule();
 else if(b.dataset.ruleToggle!==undefined){rules[Number(b.dataset.ruleToggle)].enabled=!rules[Number(b.dataset.ruleToggle)].enabled;render();}
 else if(b.hasAttribute('data-reset-demo'))location.reload();
});
window.addEventListener('scroll',positionPreview,{passive:true});
window.addEventListener('resize',positionPreview);
matchMedia('(prefers-color-scheme:dark)').addEventListener('change',()=>{if(state.appearance==='system')applyTheme();});
document.addEventListener('visibilitychange',()=>{if(document.hidden)clearHover();});
applyTheme();render();railAccess();


import {I,E,DM,PIX,FAV} from './offset-icons.js';
import {shell} from './offset-shell.js';
import {UNGROUPED} from './core.js';
import {getLanguage,workspaceLabel} from './i18n.js';
import {changeBookmarks} from './bookmarks.js';
import {renderBookmarkPanel} from './bookmark-panels.js';
import {organizeBookmarksAI} from './bookmark-ai-workflow.js';
import {groupIcon} from './group-icons.js';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const L=(zh,en)=>getLanguage()==='en'?en:zh;
const titles={workspace:['工作区','Workspace'],review:['每日回顾','Daily review'],history:['继续浏览','Continue browsing'],folders:['原文件夹','Folders'],smart:['智能分类','Collections'],manage:['工作区管理','Workspaces'],rules:['分类规则','Rules'],settings:['设置与隐私','Settings & privacy']};
const descriptions={workspace:['正在打开的标签，按主题归位','Open tabs, organized by topic'],review:['今天的注意力去了哪里','Your browsing time and journey'],history:['找回那天留下的页面，保留已有分类与人工调整','Return to saved pages, with your classifications preserved'],folders:['沿用浏览器里的收藏目录','Your original browser bookmark folders'],smart:['按主题重新整理，不动原目录','Organize by topic, keep original folders'],manage:['新建、重命名你的分类','Manage your workspaces'],rules:['让网址自动落进对应分类','Classify pages with local rules'],settings:['外观、预览与隐私','Appearance, previews and privacy']};
const fav=r=>FAV(r);
const icon=(name,label,attr='')=>`<button type="button" class="tool" aria-label="${E(label)}" title="${E(label)}" ${attr}>${I(name)}</button>`;
export class OffsetUI{
 constructor(api){
  this.api=api;this.mode='tabs';this.bookView='folders';this.panel=null;this.filters={tabs:'',bookmarks:''};this.layouts={tabs:'list',bookmarks:'list'};this.queries={tabs:'',bookmarks:''};this.density='compact';this.book=null;this.selected=null;this.previewEnabled=true;this.bookLoading=false;this.thumbnails=new Map();this.previewToken=0;
  try{const p=JSON.parse(localStorage.getItem('pickmark-view-v1')||'{}');if(['compact','comfortable'].includes(p.density))this.density=p.density;if(['list','gallery'].includes(p.layout))this.layouts.tabs=p.layout;this.previewEnabled=p.preview!==false;if(p.layout==='cards')localStorage.setItem('pickmark-view-v1',JSON.stringify({...p,layout:'list'}));}catch{}
  const main=$('main.atlas'),header=main.querySelector('header');const legacy=document.createElement('div');legacy.hidden=true;legacy.id='mono-legacy';legacy.append(header);document.body.prepend(legacy);
  const root=document.createElement('div');root.innerHTML=shell;document.body.prepend(...root.childNodes);$('#mono-placeholder').replaceWith(main);main.id='workspace';main.className='workspace atlas';
  const hero=document.createElement('div');hero.id='mono-hero';main.prepend(hero);
  hero.insertAdjacentHTML('afterend','<div id="storage-warning" class="help" role="status" hidden><span></span> <button type="button"></button></div>');
  $('#storage-warning button').onclick=()=>$('#settings-shortcut').click();
  hero.insertAdjacentHTML('afterend','<div id="book-ai-progress" class="help" role="status" hidden><span></span><button type="button" data-pm="cancel-book-ai"></button></div>');
  main.insertAdjacentHTML('beforeend','<section id="mono-list" class="stage"><section class="index"></section><aside id="inspector" class="inspector" aria-hidden="true"></aside></section><section id="mono-panel" hidden></section>');
  $('.app .top-tools').append($('#more-menu'));
  for(const id of ['reorganize','workspaces-button','rules-button','refresh'])$('#mono-legacy').append($('#'+id));
  if(!$('#statusbar'))document.body.insertAdjacentHTML('beforeend','<div id="statusbar" class="statusbar" role="status"></div>');
  document.body.insertAdjacentHTML('beforeend','<dialog id="mono-preview"><div class="dialog-heading"><h2></h2><button type="button" data-pm="close-preview" aria-label="Close">×</button></div><div class="mono-preview-body"></div></dialog><dialog id="mono-book-dialog"></dialog>');
  $('#mono-preview').addEventListener('close',()=>this.clearPreview());
  $('#search-toolbar').insertAdjacentHTML('beforeend',icon('close',L('关闭搜索','Close search'),'data-pm="search-close"'));
  $('#mono-search-toggle').innerHTML=I('search')+'<span>'+L('寻找','Search')+'</span><span class="key mono">⌘ K</span>';
  $('#menu').innerHTML=I('menu');$('#theme').innerHTML=I('moon');$('#settings').innerHTML=I('settings');$('#rail-close').innerHTML=I('close');$('#rail-about').innerHTML=I('info');
  $('#brand').onclick=()=>{this.changeMode('tabs');this.closePanel();this.filters.tabs='';this.api.home();};$('#menu').onclick=()=>this.rail(true);$('#rail-close').onclick=()=>this.rail(false);$('#rail-overlay').onclick=()=>this.rail(false);
  $('#mono-search-toggle').onclick=()=>$('#search-toggle').click();$('#settings').onclick=()=>this.navigate('settings');
  $('#theme').onclick=()=>window.atlasColorMode.set(document.documentElement.dataset.colorScheme==='dark'?'light':'dark');
  $('#rail-about').onclick=()=>this.api.toast(L('拾签 · 数据保存在本机。网站预览不会主动打开页面。','Pickmark · Data stays local. Previews never open pages automatically.'));
  document.addEventListener('click',event=>{const b=event.target.closest('button');if(!b)return;
   if(b.dataset.mode)this.changeMode(b.dataset.mode);
   if(b.dataset.pmView)this.navigate(b.dataset.pmView);
   if(b.hasAttribute('data-pm-filter')){this.filters[this.mode]=b.dataset.pmFilter;this.api.render();this.rail(false);}
   if(b.dataset.pmLayout){this.layouts[this.mode]=b.dataset.pmLayout;this.persist();this.api.render();}
   if(b.dataset.pmDensity){this.density=b.dataset.pmDensity;this.persist();this.api.render();}
   if(b.dataset.pm==='organize')this.organize();
   if(b.dataset.pm==='book-ai')this.prepareBookAI();
   if(b.dataset.pm==='cancel-book-ai')this.cancelBookAI();
   if(b.dataset.pm==='refresh')this.refreshCurrent();
   if(b.dataset.pmPage){this.bookPage=Math.max(0,(this.bookPage||0)+Number(b.dataset.pmPage));this.render();$('#mono-list').scrollIntoView({block:'start'});$('#mono-list [data-pm-page="'+b.dataset.pmPage+'"]')?.focus();}
   if(b.dataset.pm==='regroup'&&this.mode==='tabs'&&this.view==='workspace')$('#reorganize').click();
   if(b.dataset.pm==='connect')this.connectBookmarks();
   if(b.dataset.pm==='search-close')$('#search-toggle').click();
   if(b.dataset.pm==='close-preview')$('#mono-preview').close();
   if(b.dataset.pm==='preview-toggle'){this.previewEnabled=!this.previewEnabled;this.persist();b.setAttribute('aria-pressed',this.previewEnabled);b.textContent=this.previewEnabled?L('开启','On'):L('关闭','Off');}
  });
  document.addEventListener('keydown',e=>this.keyboard(e));
  $('#search').addEventListener('input',()=>{if(this.mode==='bookmarks')this.render();});
  $('#day').addEventListener('change',()=>this.clearPreview());
  window.addEventListener('scroll',()=>{this.positionPreview();document.body.classList.toggle('hero-mini',scrollY>100);},{passive:true});
  window.addEventListener('resize',()=>{this.clearPreview();if(innerWidth>800)this.rail(false);else this.railAccess();});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)this.clearPreview();});
  window.addEventListener('atlas-color-mode-change',()=>this.color());this.color();this.railAccess();
  if(this.api.extension){
   chrome.permissions?.onRemoved?.addListener(p=>{if(p.permissions?.includes('bookmarks')){this.book=null;if(this.mode==='bookmarks')this.render();}});
   for(const name of ['onCreated','onRemoved','onChanged','onMoved','onChildrenReordered'])chrome.bookmarks?.[name]?.addListener(()=>{if(this.book&&this.mode==='bookmarks')this.refreshBookmarks();});
   chrome.storage.onChanged.addListener((changes,area)=>{if(area!=='local')return;if(changes['pickmark-thumbnails-v1'])this.thumbnails.clear();if(changes['pickmark-bookmarks-v1']&&this.book&&this.mode==='bookmarks')this.refreshBookmarks();});
  }
 }
 persist(){try{localStorage.setItem('pickmark-view-v1',JSON.stringify({density:this.density,layout:this.layouts.tabs,preview:this.previewEnabled}));}catch{}}
 color(){document.documentElement.classList.toggle('night',document.documentElement.dataset.colorScheme==='dark');}
 get view(){return this.panel||(this.mode==='bookmarks'?this.bookView:this.api.view());}
 get allowsAuto(){return this.mode==='tabs'&&!this.panel;}
 filterRows(rows){return this.filters.tabs?rows.filter(r=>r.group===this.filters.tabs):rows;}
 get rows(){if(this.mode==='tabs')return this.api.rows();const q=$('#search').value.toLowerCase().trim(),key=this.bookView==='folders'?'folder':'group';return (this.book?.rows||[]).filter(r=>(!this.filters.bookmarks||r[key]===this.filters.bookmarks)&&(!q||`${r.title} ${r.domain} ${r.group} ${r.folder}`.toLowerCase().includes(q)));}
 railAccess(){$('#rail').inert=innerWidth<=800&&!$('#rail').classList.contains('open');}
 rail(open){$('#rail').classList.toggle('open',open);$('#rail-overlay').hidden=!open;$('#menu').setAttribute('aria-expanded',open);this.railAccess();if(open)$('#brand').focus();else if(innerWidth<=800)$('#menu').focus();}
 changeMode(mode){if(mode===this.mode)return;if(this.bookAIRunning)this.cancelBookAI();this.queries[this.mode]=$('#search').value;this.closePanel();this.mode=mode;$('#search').value=this.queries[mode];this.selected=null;this.clearPreview();this.api.render();if(mode==='bookmarks'&&this.api.extension)this.checkBookmarks();}
 async checkBookmarks(){try{if(await chrome.permissions.contains({permissions:['bookmarks']}))await this.refreshBookmarks();}catch(e){this.api.toast(e.message);}}
 async connectBookmarks(){try{
  if(this.api.extension&&!await chrome.permissions.request({permissions:['bookmarks']}))return;
  if(!this.api.extension&&!this.book)this.book={rows:this.api.state().records.slice(0,16).map((r,i)=>({...r,id:'demo-book-'+i,folder:L('示例书签','Example bookmarks'),folderId:'demo'})),rules:[],groups:[]};
  await this.refreshBookmarks();
 }catch(e){this.api.toast(e.message);}}
 async refreshBookmarks(){if(this.bookLoading)return;this.bookLoading=true;try{if(this.api.extension)this.book=await this.api.send({type:'bookmarks:get'});this.api.render();}catch(e){this.book=null;this.api.toast(e.message);this.render();}finally{this.bookLoading=false;}}
 async refreshCurrent(){try{if(this.mode==='bookmarks'){if(!this.book)return this.connectBookmarks();await this.refreshBookmarks();}else await this.api.refresh();}catch(e){this.api.toast(e.message);}}
 async bookSend(action,payload={}){
  const message={type:'bookmarks:'+action,expectedRevision:this.book?.revision||0,...payload};
  if(this.api.extension)this.book=await this.api.send(message);
  else this.book=changeBookmarks(this.book,message);
  this.render();
 }
 async navigate(view){
  this.clearPreview();this.rail(false);this.closePanel();
  if(['settings','manage','rules'].includes(view)){
   if(this.mode==='bookmarks'&&view!=='settings'){this.panel=view;this.render();return;}
   const trigger={settings:'settings-shortcut',manage:'workspaces-button',rules:'rules-button'}[view];$('#'+trigger).click();return;
  }
  this.filters[this.mode]='';if(this.mode==='bookmarks'){this.bookView=view;this.render();}else this.api.switchView(view);
  window.scrollTo(0,0);
 }
 openPanel(id,view){this.closePanel();this.panel=view;if(this.mode==='bookmarks'&&view!=='settings'){this.render();return;}const dialog=$('#'+id);dialog.classList.add('mono-page');$('#mono-panel').append(dialog);dialog.show();
  if(id==='settings-dialog')this.settingsExtras(dialog);
  if(!dialog.dataset.monoBound){dialog.dataset.monoBound='true';dialog.addEventListener('close',()=>{if(!dialog.open&&this.panel===view){this.panel=null;dialog.classList.remove('mono-page');document.body.append(dialog);this.api.render();}});}
  this.render();window.scrollTo(0,0);
 }
 closePanel(){const previous=this.panel;this.panel=null;for(const d of $$('#mono-panel dialog.mono-page')){d.close();d.classList.remove('mono-page');document.body.append(d);}$('#mono-panel').replaceChildren();return previous;}
 settingsExtras(dialog){if(!$('#mono-appearance')){
  const block=document.createElement('section');block.id='mono-appearance';block.innerHTML='<h3>'+L('界面与交互','Appearance & interaction')+'</h3>';
  block.append($('.appearance-controls'));block.insertAdjacentHTML('beforeend',`<div class="setting-row"><div><strong>${L('悬停缩略图','Hover previews')}</strong><p>${L('无缓存时显示页面信息，不主动打开或抓取网页。','Show page information when no cached image is available.')}</p></div><button type="button" class="toggle" data-pm="preview-toggle" aria-pressed="${this.previewEnabled}">${this.previewEnabled?L('开启','On'):L('关闭','Off')}</button></div>`);
  dialog.querySelector('form').insertBefore(block,dialog.querySelector('h3'));
  const form=dialog.querySelector('form'),grid=document.createElement('div'),right=document.createElement('section');grid.className='settings-grid';right.className='settings-section';block.classList.add('settings-section');
  for(const child of [...form.children])if(child!==block&&!child.classList.contains('dialog-heading'))right.append(child);
  grid.append(block,right);form.append(grid);
 }}
 render(){
  const state=this.api.state();if(!state)return;this.clearPreview();const view=this.view,rows=this.rows,book=this.mode==='bookmarks',panel=!!this.panel,reviewSearch=view==='review'&&!!$('#search').value.trim();
  document.body.classList.add('offset-live');document.documentElement.classList.toggle('dense',this.density==='compact');document.body.dataset.monoView=view;
  const names=titles[view]||titles.workspace,desc=descriptions[view]||descriptions.workspace;
  const count=view==='manage'?(book?new Set([...(this.book?.groups||[]),...(this.book?.rows||[]).map(r=>r.group),...(this.book?.rules||[]).map(r=>r.group)].filter(g=>g!==UNGROUPED)).size:this.api.names().length):view==='rules'?(book?this.book?.rules.length||0:state.config.rules.length):view==='settings'?3:rows.length;
  const label=panel?L('项','items'):book?L('条书签','bookmarks'):L('个页面','pages');
  const pending=rows.filter(r=>r.group===UNGROUPED&&!r.manualGroup).length;
  $('#mono-hero').innerHTML=`<section class="hero"><div class="hero-icon" aria-hidden="true">${PIX(view)}</div><div class="hero-text"><h1>${L(...names)}</h1><p class="hero-sub">${L(...desc)}</p></div>${!panel&&view!=='review'?`<button class="button hero-action ${pending?'primary':''}" data-pm="organize" ${this.api.busy()?'disabled':''}>${view==='history'?L('历史补分类','Classify history'):L(book?'应用书签规则':'整理待分类',book?'Apply bookmark rules':'Organize unclassified')}${pending?`<span class="badge mono">${pending}</span>`:''}${I('arrow')}</button>`:''}<div class="hero-stat"><strong>${DM(count)}</strong><span class="mono">${label}</span></div></section>`;
  if(['manage','rules'].includes(view))$('#mono-hero h1').textContent=L(book?(view==='manage'?'书签分类管理':'书签分类规则'):(view==='manage'?'标签分类管理':'标签分类规则'),book?(view==='manage'?'Bookmark categories':'Bookmark rules'):(view==='manage'?'Tab categories':'Tab rules'));
  $('#top-title').textContent=$('#mono-hero h1').textContent;document.title=L('拾签','Pickmark');
  $('#storage-warning').hidden=!state.storageWarning;
  $('#storage-warning span').textContent=L('存储空间不足，正在显示已保存的数据。新记录暂时无法保存，请到设置清理缓存或历史记录。','Storage is full. Showing saved data; new activity may not be saved. Open settings to clear cached previews or history.');
  $('#storage-warning button').textContent=L('设置与清理','Settings & cleanup');
  $('#book-ai-progress').hidden=!book||!this.bookAIStatus;
  $('#settings-shortcut').textContent=L('设置与隐私','Settings & privacy');
  $('#search').placeholder=L(book?'搜索书签标题、域名或分类…':'搜索当前标签清单…',book?'Search bookmark titles, domains or categories…':'Search the current tab list…');
  $$('[data-mode]').forEach(b=>{b.classList.toggle('active',b.dataset.mode===this.mode);b.setAttribute('aria-pressed',b.dataset.mode===this.mode);b.querySelector('sup').textContent=b.dataset.mode==='tabs'?state.tabs.length:this.book?.rows.length??'—';b.querySelector('strong').textContent=b.dataset.mode==='tabs'?L('标签页','Tabs'):L('书签','Bookmarks');});
  const source=book?this.book?.rows||[]:this.api.scoped(),key=book&&this.bookView==='folders'?'folder':'group';
  const categories=[...new Set(source.map(r=>r[key]))];
  if(!book||this.bookView==='smart'){const order=book?this.book?.groups||[]:this.api.names();categories.sort((a,b)=>order.indexOf(a)-order.indexOf(b));}
  if(this.selected&&!rows.some(r=>r.id===this.selected.id))this.selected=rows[0]||null;
  const nav=(v,ic)=>`<button class="nav ${view===v?'active':''}" data-pm-view="${v}" ${view===v?'aria-current="page"':''}>${I(ic)}<span>${L(...titles[v])}</span>${['workspace','folders'].includes(v)?`<span class="number mono">${v==='workspace'?state.tabs.length:this.book?.rows.length??'—'}</span>`:''}</button>`;
  const primary=book?nav('folders','folder')+nav('smart','spark'):nav('workspace','tabs')+nav('review','clock')+nav('history','history');
  const q=$('#nav-filter')?.value||'';
  $('#nav').innerHTML=`<div class="nav-group nav-primary"><p class="rail-label mono">${book?L('收藏','Collection'):L('浏览','Browsing')}</p>${primary}</div>${!panel&&view!=='review'?`<div class="nav-group nav-cats"><p class="rail-label mono">${key==='folder'?L('目录','Folders'):L('分类','Groups')}<span>${categories.length}</span></p>${categories.length>6?`<label class="nav-find">${I('search')}<input id="nav-filter" aria-label="${L('筛选分类','Filter groups')}" placeholder="${L('筛选分类','Filter groups')}" value="${E(q)}"></label>`:''}<div class="nav-scroll"><button class="nav cat ${!this.filters[this.mode]?'active':''}" data-pm-filter="">${I('all')}<span class="group-label">${L('全部','All')}</span><span class="number mono">${source.length}</span></button>${categories.map(name=>{const items=source.filter(r=>r[key]===name);return `<button class="nav cat ${this.filters[this.mode]===name?'active':''}" data-pm-filter="${E(name)}">${groupIcon(name,book?this.book?.icons?.[name]:state.config.workspaceIcons?.[name])}<span class="group-label">${E(key==='folder'?name.split(' / ').at(-1):workspaceLabel(name))}</span><span class="number mono">${items.length}</span></button>`;}).join('')}</div></div>`:''}<div class="nav-dock">${[['manage','grid'],['rules','spark'],['settings','settings']].map(([v,ic])=>`<button class="dock ${view===v?'active':''}" data-pm-view="${v}" title="${L(...titles[v])}" aria-label="${L(...titles[v])}">${I(ic)}<span>${L(...{manage:['管理','Manage'],rules:['规则','Rules'],settings:['设置','Settings']}[v])}</span></button>`).join('')}</div>`;
  if($('#nav-filter'))$('#nav-filter').oninput=e=>$$('[data-pm-filter]').forEach(b=>b.hidden=!!b.dataset.pmFilter&&!b.textContent.toLowerCase().includes(e.target.value.toLowerCase()));
  $('#mono-panel').hidden=!panel;$('#recap').hidden=panel||book||view==='workspace';$('#review-dashboard').hidden=panel||book||view!=='review';
  $('#ai-onboarding').hidden=$('#ai-onboarding').hidden||book||panel;
  for(const id of ['history-progress','organize-progress','ai-recovery'])if(book||panel)$('#'+id).hidden=true;
  $('#mono-list').hidden=panel||(view==='review'&&!reviewSearch);
  if(panel&&book&&view!=='settings')this.renderBookPanel(view);
  if(!panel&&(view!=='review'||reviewSearch))this.renderList(rows);
  this.status(rows);this.railAccess();
 }
 renderList(rows){
  const book=this.mode==='bookmarks',view=this.view,layout=this.layouts[this.mode];
  const total=rows.length,pageSize=100;
  if(book){const key=JSON.stringify([view,this.filters.bookmarks,$('#search').value]);if(key!==this.bookPageKey){this.bookPage=0;this.bookPageKey=key;}this.bookPage=Math.min(this.bookPage||0,Math.max(0,Math.ceil(total/pageSize)-1));rows=rows.slice(this.bookPage*pageSize,(this.bookPage+1)*pageSize);}
  const controls=`${icon('dense',L('紧凑行距','Compact'),`data-pm-density="compact" aria-pressed="${this.density==='compact'}"`)}${icon('airy',L('舒适行距','Comfortable'),`data-pm-density="comfortable" aria-pressed="${this.density==='comfortable'}"`)}<span class="vsep"></span>${icon('list',L('索引列表','List'),'data-pm-layout="list"')}${icon('grid',L('预览画廊','Gallery'),'data-pm-layout="gallery"')}`;
  let html=`<div class="list-tools"><div class="scope"><strong>${E(this.filters[this.mode]||L(book?'全部书签':'全部标签',book?'All bookmarks':'All tabs'))}</strong><span class="mono">/ ${total}</span></div><div class="view-controls">${book?`<button class="tool" data-pm="book-ai" ${this.bookAIRunning?'disabled':''}>${L('AI 分类…','AI classify…')}</button>`:''}<button class="tool" data-pm="refresh">${L(book?'刷新书签':'刷新标签页',book?'Refresh bookmarks':'Refresh tabs')}</button>${!book&&view==='workspace'?`<button class="tool" data-pm="regroup">${L('重新分组…','Regroup…')}</button>`:''}${controls}</div></div>`;
  if(book&&!this.book){html+=`<div class="empty"><p>${L('连接浏览器书签','Connect browser bookmarks')}</p><span>${L('仅在你授权后读取目录。智能分类独立保存，不移动原书签。','Read folders only after your permission. Classification never moves original bookmarks.')}</span><button class="button primary" data-pm="connect">${this.api.extension?L('授权并读取书签','Authorize bookmarks'):L('查看模拟书签','Show example bookmarks')}</button></div>`;}
  else if(!rows.length)html+=`<div class="empty"><p>${L('这里还没有页面','No pages here')}</p><span>${L('可以切换分类、日期或清除搜索条件。','Choose another group or date, or clear the search.')}</span></div>`;
  else if(layout==='gallery')html+=`<div class="gallery">${rows.map(r=>`<button class="gallery-card" data-pm-preview="${E(r.id)}"><div class="gallery-art">${this.previewMarkup(r)}</div><div class="gallery-copy"><strong>${E(r.title)}</strong><span>${E(r.domain)} · ${E(workspaceLabel(r.group))}</span></div></button>`).join('')}</div>`;
  else html+=rows.map(r=>this.row(r,book,view)).join('');
  if(book&&total>pageSize)html+=`<nav class="bookmark-pager" aria-label="${L('书签分页','Bookmark pages')}"><button class="button" data-pm-page="-1" ${this.bookPage===0?'disabled':''}>${L('上一页','Previous')}</button><span class="mono">${this.bookPage*pageSize+1}–${Math.min(total,(this.bookPage+1)*pageSize)} / ${total}</span><button class="button" data-pm-page="1" ${(this.bookPage+1)*pageSize>=total?'disabled':''}>${L('下一页','Next')}</button><small>${L('搜索与整理覆盖全部匹配结果','Search and organize include all matching results')}</small></nav>`;
  $('#mono-list .index').innerHTML=html;
  $$('#mono-list [data-pm-open]').forEach(b=>b.onclick=()=>this.open(rows.find(r=>r.id===b.dataset.pmOpen)));
  $$('#mono-list [data-pm-edit]').forEach(b=>b.onclick=()=>this.edit(rows.find(r=>r.id===b.dataset.pmEdit)));
  $$('#mono-list [data-pm-preview]').forEach(b=>b.onclick=()=>this.preview(rows.find(r=>r.id===b.dataset.pmPreview),true));
  $$('#mono-list .item').forEach(row=>{const r=rows.find(r=>r.id===row.dataset.row);const enter=()=>{this.clearPreview();this.selected=r;row.classList.add('is-hovered');this.status(rows);if(this.previewEnabled&&innerWidth>700)this.hoverTimer=setTimeout(()=>this.preview(r),matchMedia('(prefers-reduced-motion: reduce)').matches?0:480);};row.onmouseenter=enter;row.onmouseleave=()=>{if(!row.querySelector(':focus-visible'))this.clearPreview();};row.addEventListener('focusin',e=>{this.selected=r;this.status(rows);if(e.target.matches(':focus-visible'))enter();});row.addEventListener('focusout',e=>{if(!row.contains(e.relatedTarget))this.clearPreview();});});
 }
 row(r,book,view){const name=r.title.includes(' · ')?r.title.split(' · ')[0]:r.domain.split('.')[0],title=r.title.includes(' · ')?r.title.split(' · ').slice(1).join(' · '):r.title;
  const date=r.lastSeen||r.firstSeen,time=date?new Date(date).toLocaleDateString(getLanguage()==='en'?'en-US':'zh-CN',{month:'2-digit',day:'2-digit'}):'';
  return `<div class="item" data-row="${E(r.id)}"><div class="row-origin"><span class="row-origin-text">${fav(r)}<strong>${E(name)}</strong></span></div><div class="row-stripes" aria-hidden="true">${Array.from({length:12},(_,n)=>`<i style="--weight:${1/(n+2)};--delay:${180+n*12}ms"></i>`).join('')}</div><div class="row-details"><button class="item-main" data-pm-open="${E(r.id)}"><span class="item-title">${E(title)}${r.manualGroup?`<span class="manual-tag">${L('手动','Manual')}</span>`:''}</span><span class="item-meta">${E(book&&view==='folders'?r.folder:r.domain)}</span></button><span class="row-state mono">${E(time)}</span><span class="row-group">${E(workspaceLabel(r.group))}</span><span class="item-actions">${icon('eye',L('预览','Preview'),'data-pm-preview="'+E(r.id)+'"')}${icon('more',L('调整分类','Edit classification'),'data-pm-edit="'+E(r.id)+'"')}</span></div></div>`;
 }
 previewMarkup(r){const image=this.thumbnails.get(r.url);if(image)return `<img class="cached-thumbnail" src="${E(image)}" alt="${E(r.title)}">`;return `<div class="placeholder-art"><span class="mono">${E(r.domain)}</span><strong>${E(r.title)}</strong><p>${L('尚无网页缩略图','No cached webpage thumbnail')}</p><small>${L('不主动打开或采集此页面','This page is not opened or captured automatically')}</small></div>`;}
 cacheThumbnail(url,image){this.thumbnails.delete(url);this.thumbnails.set(url,image);while(this.thumbnails.size>20)this.thumbnails.delete(this.thumbnails.keys().next().value);}
 preview(r,explicit=false){
  if(!r)return;if(explicit)this.clearPreview();else if(document.querySelector('dialog[open]:not(.mono-page)'))return;
  const token=++this.previewToken;
  const draw=()=>{
   if(token!==this.previewToken)return;
   if(explicit){$('#mono-preview h2').textContent=r.title;$('#mono-preview .mono-preview-body').innerHTML=this.previewMarkup(r)+(this.api.extension?`<p class="help">${L('仅保存当前可见网页，最多保留 10 张、7 天。请在网页的侧边栏中操作。','Save only the currently visible page from its side panel. Up to 10 images, retained for 7 days.')}</p><button type="button" id="mono-capture" class="button">${L('保存当前网页缩略图','Save visible page thumbnail')}</button>`:'');
    if($('#mono-capture'))$('#mono-capture').onclick=async()=>{try{const image=await this.api.send({type:'thumbnail:capture',url:r.url});this.cacheThumbnail(r.url,image);draw();}catch(e){this.api.toast(e.message);}};
    if(!$('#mono-preview').open)$('#mono-preview').showModal();
   }else{$('#inspector').innerHTML='<div class="floating-art">'+this.previewMarkup(r)+'</div><div class="floating-caption">'+E(r.domain)+'</div>';$('#inspector').classList.add('is-visible');$('#inspector').setAttribute('aria-hidden','false');this.positionPreview();}
  };draw();
  if(this.api.extension&&!this.thumbnails.has(r.url))this.api.send({type:'thumbnail:get',url:r.url}).then(image=>{this.cacheThumbnail(r.url,image);draw();}).catch(()=>{});
 }
 clearPreview(){this.previewToken++;clearTimeout(this.hoverTimer);$$('.item.is-hovered').forEach(r=>r.classList.remove('is-hovered'));$('#inspector')?.classList.remove('is-visible');$('#inspector')?.setAttribute('aria-hidden','true');}
 positionPreview(){const p=$('#inspector');if(!p?.classList.contains('is-visible'))return;const box=$('#mono-list').getBoundingClientRect(),width=Math.min(480,box.width*.47),height=width*420/640+30,bar=$('.app .topbar').getBoundingClientRect().bottom;if(box.bottom<bar+80||box.top>innerHeight-60){this.clearPreview();return;}p.style.width=width+'px';p.style.left=box.right-width+'px';p.style.top=Math.max(bar+8,Math.min(innerHeight-height-30,Math.max(box.top+40,box.bottom-height-20)))+'px';}
 async open(r){if(!r)return;try{if(this.mode==='bookmarks'){if(!this.api.extension){this.api.toast(L('模拟书签，不打开外部网站。','Example bookmark; no external page opened.'));return;}const url=new URL(r.url);if(!['https:','http:'].includes(url.protocol))return;await chrome.tabs.create({url:r.url});}else await this.api.send({type:'jump',id:r.id});}catch(e){this.api.toast(e.message);}}
 edit(r){if(!r)return;if(this.mode==='tabs'){this.api.edit(r);return;}const expectedRevision=this.book.revision||0;this.bookDialog(L('调整智能分类','Edit classification'),`<p>${E(r.title)}</p><p class="help">${E(r.folder)}</p><label>${L('分类名称','Group name')}<input id="mono-book-group" maxlength="40" required value="${E(r.group)}"></label>`,async()=>this.bookSend('patch',{expectedRevision,id:r.id,url:r.url,group:$('#mono-book-group').value}));}
 bookDialog(title,body,save){const d=$('#mono-book-dialog');d.innerHTML=`<form><div class="dialog-heading"><h2>${title}</h2><button type="button" aria-label="Close">×</button></div>${body}<div class="dialog-actions"><button class="primary">${L('保存','Save')}</button></div></form>`;d.querySelector('button[type=button]').onclick=()=>d.close();d.querySelector('form').onsubmit=async e=>{e.preventDefault();try{await save();d.close();}catch(error){this.api.toast(error.message);}};d.showModal();}
 async organize(){try{if(this.mode==='bookmarks'){if(!this.book)return this.connectBookmarks();await this.bookSend('classify',{ids:this.rows.map(r=>r.id)});this.api.toast(L('已应用书签规则；已有分类与人工调整保持不变。','Bookmark rules applied; existing and manual classifications preserved.'));}else if(this.view==='history')$('#organize-history').click();else await this.api.organize();}catch(e){this.api.toast(e.message);}}
 async prepareBookAI(){
  if(this.bookAIRunning)return;
  if(!this.api.extension){this.api.toast(L('模拟预览不发送 AI 请求；加载扩展后可确认范围。','Demo does not send AI requests. Load the extension to confirm a scope.'));return;}
  if(!this.book)return this.connectBookmarks();
  try{
   const prepared=await this.api.send({type:'bookAI:prepare',ids:this.rows.map(r=>r.id)});if(this.mode!=='bookmarks')return;
   this.bookDialog(L('确认书签 AI 分类','Confirm bookmark AI classification'),`<p>${E(this.filters.bookmarks||L('全部书签','All bookmarks'))}${$('#search').value?' · '+E($('#search').value):''}</p><p>${L('范围','Scope')} ${prepared.total} · ${L('保留已有/人工分类','Existing/manual protected')} ${prepared.protected} · ${L('本地规则','Local rules')} ${prepared.local} · AI ${prepared.ai}</p><p>${E(prepared.provider)} / ${E(prepared.model)}</p><p class="help">${L('仅发送待分类书签的标题、域名、分类名称与规则到上述供应商，可能产生 API 费用。不发送完整网址、原文件夹路径或网页正文。每批最多 200 条；取消保留已完成结果。','Send only unclassified bookmark titles, domains, category names and rules to this provider. API charges may apply. No full URLs, folder paths or page content. Up to 200 per batch; cancellation preserves completed work.')}</p><div class="preview-list">${prepared.preview.map(r=>`<div>${E(r.title)} · ${E(r.domain)}</div>`).join('')}</div><p class="help">${prepared.ai>50?L('仅展示前 50 条，确认范围包含全部待分类结果。','Preview shows 50; confirmation includes all candidates.'):''}${!prepared.hasKey?L('请先在设置中配置 AI Key。','Configure an AI key in Settings first.'):''}</p>`,async()=>{if(!prepared.hasKey||!prepared.ai)return;$('#mono-book-dialog').close();void this.runBookAI(prepared);});
   const button=$('#mono-book-dialog .primary');button.textContent=L('确认发送','Confirm and send');button.disabled=!prepared.hasKey||!prepared.ai;
  }catch(e){this.api.toast(e.message);}
 }
 cancelBookAI(){this.bookAICancelled=true;if(this.bookAIToken)this.api.send({type:'bookAI:cancel',token:this.bookAIToken}).catch(()=>{});}
 async runBookAI(prepared){
  if(this.bookAIRunning)return;this.bookAIRunning=true;this.bookAICancelled=false;this.bookAIToken=crypto.randomUUID();
  const show=text=>{this.bookAIStatus=text;$('#book-ai-progress span').textContent=text;$('#book-ai-progress').hidden=this.mode!=='bookmarks';};
  const cancel=$('#book-ai-progress button');cancel.hidden=false;cancel.textContent=L('取消','Cancel');
  show(L('正在处理书签…','Classifying bookmarks…'));
  try{const result=await organizeBookmarksAI({send:this.api.send,prepared,token:this.bookAIToken,shouldContinue:()=>!this.bookAICancelled&&this.mode==='bookmarks',onProgress:r=>show(L(`AI 已完成 ${r.applied} · 剩余 ${r.remaining}`,`AI completed ${r.applied} · Remaining ${r.remaining}`))});show(L(`已保存 ${result.applied} 条 AI 分类${result.stopped?'，已停止后续批次':''}；未分类条目可重新确认后重试。`,`Saved ${result.applied} AI assignments. Reconfirm to retry remaining items.`));}
  catch(e){show(L('处理中断，已完成结果保留。重新点击 AI 分类确认范围后重试。 ','Interrupted; completed results preserved. Reconfirm AI classification to retry. ')+e.message);}
  finally{this.bookAIRunning=false;this.bookAIToken=null;cancel.hidden=true;await this.refreshBookmarks();}
 }
 status(rows){const state=this.api.state(),book=this.mode==='bookmarks',pending=rows.filter(r=>r.group===UNGROUPED&&!r.manualGroup).length;$('#statusbar').innerHTML=`<span class="sb-left"><span class="dot"></span>${rows.length} ${book?L('条书签','bookmarks'):L('个页面','pages')} · ${pending} ${L('待整理','unclassified')}${this.selected?'<span class="sep">·</span><span class="cursor">▸ '+E(this.selected.title)+'</span>':''}</span><span class="sb-right"><span class="k"><kbd>↑↓</kbd>${L('移动','Move')}</span><span class="k"><kbd>↵</kbd>${L('打开','Open')}</span><span class="k"><kbd>Space</kbd>${L('预览','Preview')}</span><span class="k"><kbd>E</kbd>${L('整理','Organize')}</span><span class="k"><kbd>/</kbd>${L('搜索','Search')}</span><span class="sep">·</span>${this.api.extension?(state.config.recording?L('本地记录','Local recording'):L('记录已暂停','Recording paused')):L('模拟数据','Example data')}</span>`;}
 keyboard(e){
 if(document.querySelector('dialog[open]:not(.mono-page)'))return;
 if(e.key==='Tab'&&$('#rail').classList.contains('open')){const items=[...$('#rail').querySelectorAll('button,input')].filter(n=>!n.hidden&&n.offsetParent!==null),first=items[0],last=items.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}return;}
 if(e.key==='Escape'){this.clearPreview();if($('#rail').classList.contains('open'))this.rail(false);if(!$('#search-toolbar').hidden)$('#search-toggle').click();return;}
 if(e.target.closest('input,textarea,select,[contenteditable=true]'))return;if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('#search-toggle').click();return;}if(e.metaKey||e.ctrlKey||e.altKey)return;if(e.key==='Escape'){this.clearPreview();this.rail(false);return;}if(e.key==='/'){e.preventDefault();$('#search-toggle').click();return;}if(this.panel)return;const list=$$('#mono-list [data-pm-open]'),index=list.indexOf(document.activeElement);if(['ArrowDown','ArrowUp','j','k'].includes(e.key)){if(!list.length)return;e.preventDefault();const delta=['ArrowDown','j'].includes(e.key)?1:-1;list[Math.max(0,Math.min(list.length-1,index<0?(delta>0?0:list.length-1):index+delta))].focus();}else if(e.key===' '&&index>=0){e.preventDefault();this.preview(this.selected,true);}else if(e.key.toLowerCase()==='e'){e.preventDefault();this.organize();}else if(['Backspace','Delete'].includes(e.key)&&index>=0&&this.mode==='tabs'&&this.view==='workspace'){e.preventDefault();this.api.close(this.selected);}}
 renderBookPanel(view){renderBookmarkPanel(this,view);}
}

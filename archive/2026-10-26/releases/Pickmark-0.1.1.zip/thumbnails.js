import {excludedUrl} from './core.js';
import {writeLocal} from './storage-budget.js';
export const THUMBNAIL_KEY='pickmark-thumbnails-v1';
const MAX_BYTES=1_500_000,MAX_ITEMS=10,MAX_AGE=7*86400000;
export function retainThumbnails(cache,excluded=[],now=Date.now()){
 let bytes=0;const entries=Object.entries(cache||{}).filter(([url,v])=>{
  try{return ['http:','https:'].includes(new URL(url).protocol)&&!excludedUrl(url,excluded)&&v?.at>now-MAX_AGE&&typeof v.image==='string'&&/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(v.image);}catch{return false;}
 }).sort((a,b)=>b[1].at-a[1].at);
 return Object.fromEntries(entries.filter(([url,v],i)=>{const size=url.length+v.image.length;if(i>=MAX_ITEMS||bytes+size>MAX_BYTES)return false;bytes+=size;return true;}));
}
// Capture is explicit and restricted to the already-visible requested page.
export async function handleThumbnail(message,api,config){
 const url=new URL(message.url);if(!['https:','http:'].includes(url.protocol)||excludedUrl(url.href,config.excluded))throw Error('此页面不允许保存预览');
 const stored=(await api.storage.local.get(THUMBNAIL_KEY))[THUMBNAIL_KEY]||{};
 const cache=retainThumbnails(stored,config.excluded);
 if(message.type==='thumbnail:get'){
  if(JSON.stringify(cache)!==JSON.stringify(stored))await writeLocal({[THUMBNAIL_KEY]:cache},api);
  return cache[url.href]?.image||null;
 }
 if(message.type!=='thumbnail:capture')throw Error('未知预览操作');
 const [tab]=await api.tabs.query({active:true,lastFocusedWindow:true});
 if(!tab||tab.incognito||tab.url!==url.href)throw Error('请在该网页当前可见时，通过侧边栏保存预览');
 const image=await api.tabs.captureVisibleTab(tab.windowId,{format:'jpeg',quality:40});
 const current=await api.tabs.get(tab.id);
 if(!current.active||current.url!==url.href)throw Error('当前页面已变化，未保存缩略图');
 cache[url.href]={image,at:Date.now()};const next=retainThumbnails(cache,config.excluded);
 if(!next[url.href])throw Error('缩略图过大，未保存');
 await writeLocal({[THUMBNAIL_KEY]:next},api);return image;
}
